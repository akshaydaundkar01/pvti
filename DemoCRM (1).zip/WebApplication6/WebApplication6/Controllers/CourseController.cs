﻿using Domain_Layer.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Service_Layer.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication6.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CourseController : ControllerBase
    {
        private readonly ICourseService _courseService;

        public CourseController(ICourseService courseService)
        {
            _courseService = courseService;
        }

        [HttpGet(nameof(GetAllCourse))]
        public IActionResult GetAllCourse()
        {
            var res = _courseService.GetAllCourses();
            if(res is not null)
            {
                return Ok(res);
            }
            return BadRequest("No Record Found");
        }

        [HttpGet(nameof(GetCourse))]
        public IActionResult GetCourse(int id)
        {
            var res = _courseService.GetCourse(id);
            if (res is not null)
            {
                return Ok(res);
            }
            return BadRequest("No Record Found");
        }

        [HttpPost(nameof(InsertCourse))]
        public IActionResult InsertCourse(Course course)
        {
            _courseService.InsertCourse(course);
            return Ok("Data Saved SuccessFully");
        }


        [HttpPut(nameof(UpdateCourse))]
        public IActionResult UpdateCourse(Course course)
        {
            _courseService.UpdateCourse(course);
            return Ok("Data Updated Successfully");
        }

        [HttpDelete(nameof(DeleteCourse))]
        public IActionResult DeleteCourse(int id)
        {
            _courseService.DeleteCourse(id);
            return Ok("Data Deleted Successfully");
        }

    }
}
