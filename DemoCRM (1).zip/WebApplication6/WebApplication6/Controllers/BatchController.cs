﻿using Domain_Layer.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Service_Layer.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication6.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BatchController : ControllerBase
    {
        private readonly IBatchService _batchService;

        public BatchController(IBatchService batchService)
        {
            _batchService = batchService;
        }

        [HttpGet(nameof(GetAllBatches))]
        public IActionResult GetAllBatches()
        {
            var res = _batchService.GetAllBatches();
            if (res != null)
            {
                return Ok(res);
            }
            return BadRequest("Batch not found");
            
        }

        [HttpGet(nameof(GetBatch))]
        public IActionResult GetBatch(int Id)
        {
            var res = _batchService.GetBatch(Id);
            if (res != null)
            {
                return Ok(res);
            }
            return BadRequest("Batch Not found");
        }

        [HttpPost(nameof(InsertBatch))]
        public IActionResult InsertBatch(Batch batch)
        {
            _batchService.InsertBatch(batch);
            return Ok("Batch Inserted Sucessfully ");
        }

        [HttpPut(nameof(UpdateBatch))]
        public IActionResult UpdateBatch(Batch batch)
        {
            _batchService.UpdateBatch(batch);
            return Ok("Batch Updated Sucessfully ");
        }

        [HttpDelete(nameof(DeleteBatch))]
        public IActionResult DeleteBatch(int id)
        {
            _batchService.DeleteBatch(id);
            return BadRequest("Batch Deleted");
        }

    }
}
